import type { ReactNode } from "react";
import { ShieldCheck } from "lucide-react";
import type { Tier } from "@/lib/demo";
import { DashboardFrame } from "@/components/DashboardFrame";

export function EscrowBadge({ small }: { small?: boolean }) {
  return (
    <span className={`inline-flex items-center gap-1 rounded-full border border-accent/60 bg-accent/10 font-mono text-accent ${small ? "px-2 py-0.5 text-[10px]" : "px-3 py-1 text-xs"}`}>
      <ShieldCheck className={small ? "h-3 w-3" : "h-4 w-4"} /> ESCROW PROTECTED
    </span>
  );
}

export function TierBadge({ tier }: { tier: Tier }) {
  const tone = tier === 3 ? "text-accent border-accent bg-accent/15" : tier === 2 ? "text-accent border-accent/50" : "text-accent/80 border-accent/30";
  return <span className={`rounded border px-1.5 py-0.5 font-mono text-[10px] ${tone}`}>VERIFY L{tier}</span>;
}

export function Shell({ title, children }: { title: string; children: ReactNode }) {
  return (
    <DashboardFrame>
      <main className="mx-auto max-w-6xl px-5 py-8 md:px-10">
        <h1 className="mb-6 font-display text-3xl font-bold leading-tight tracking-tight">{title}</h1>
        {children}
      </main>
    </DashboardFrame>
  );
}

export function Panel({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="rounded-lg border border-border bg-card p-5">
      <h2 className="mb-4 font-mono text-xs uppercase tracking-widest text-muted-foreground">{title}</h2>
      {children}
    </section>
  );
}

export function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="min-w-0 overflow-hidden rounded-lg border border-border bg-card p-4">
      <div className="truncate font-mono text-xs text-muted-foreground">{label}</div>
      <div className="mt-1 truncate text-xl font-bold tabular-nums text-gold xl:text-2xl" title={value}>{value}</div>
    </div>
  );
}

export function Row({ children }: { children: ReactNode }) {
  return <div className="flex items-center justify-between gap-3 border-b border-border py-2.5 text-sm last:border-0">{children}</div>;
}
