import { Link } from "@tanstack/react-router";
import { useState, type ReactNode } from "react";
import { Home, User, Store, ShieldCheck, Compass, MessageSquare, ChevronDown, Menu, X, Ticket } from "lucide-react";
import { Button } from "@/components/ui/button";
import logo from "@/assets/dealer-logo.asset.json";

const navigation = [
  { to: "/", label: "Home", icon: Home },
  { to: "/buyer", label: "Buyer Portal", icon: User },
  { to: "/seller", label: "Seller Dashboard", icon: Store },
  { to: "/escrow", label: "Middle Man (Escrow)", icon: ShieldCheck },
  { to: "/shop", label: "Window Shop", icon: Compass },
  { to: "/deals", label: "Messages", icon: MessageSquare },
] as const;

export function DashboardFrame({ children }: { children: ReactNode }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [bannerVisible, setBannerVisible] = useState(true);
  return (
    <div className="reference-dashboard min-h-screen bg-background text-foreground">
      <div className="flex min-h-screen">
        <aside className={`${menuOpen ? "fixed inset-y-0 left-0 z-30 flex shadow-xl" : "hidden"} reference-sidebar w-[29%] min-w-64 max-w-80 shrink-0 flex-col justify-between bg-sidebar md:sticky md:top-0 md:flex md:h-screen`}>
          <div>
            <div className="relative flex flex-col items-center px-6 pb-5 pt-5">
              <Link to="/" aria-label="dealer2470 home"><img src={logo.url} alt="dealer2470" className="h-44 w-32 object-contain" /></Link>
              {menuOpen && <Button size="icon" variant="ghost" className="ml-auto md:hidden" aria-label="Close navigation" onClick={() => setMenuOpen(false)}><X /></Button>}
            </div>
            <nav className="space-y-1 px-2" aria-label="Main navigation">
              {navigation.map(({ to, label, icon: Icon }) => <Link key={to} to={to} activeOptions={{ exact: to === "/" }} onClick={() => setMenuOpen(false)} className="flex min-h-11 items-center gap-3 rounded-lg px-3 py-2 text-base text-foreground transition-colors hover:bg-secondary" activeProps={{ className: "bg-secondary text-primary" }}><Icon className="h-5 w-5 shrink-0 text-primary" strokeWidth={1.5} />{label}</Link>)}
            </nav>
          </div>
          <div className="p-4">
            <details className="group relative">
              <summary className="flex cursor-pointer list-none items-center gap-3 py-3"><span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-accent text-2xl text-accent-foreground">D</span><span className="min-w-0 flex-1"><span className="block text-base font-semibold">Dealer</span><span className="block text-sm text-muted-foreground">Harts</span></span><ChevronDown className="h-4 w-4 text-muted-foreground group-open:rotate-180" /></summary>
              <div className="space-y-1 border-t border-border p-2">{navigation.slice(1, 4).map(n => <Link key={n.to} to={n.to} className="block rounded px-2 py-2 text-xs text-muted-foreground hover:bg-secondary hover:text-foreground">{n.label}</Link>)}</div>
            </details>
            <Link to="/buyer" className="mt-2 flex items-center gap-3 border-t border-border py-4"><Ticket className="h-9 w-9 rounded-full bg-secondary p-2 text-primary" /><span className="text-sm"><span className="block text-muted-foreground">Credit Info (modified)</span>Share Dealer247</span></Link>
          </div>
        </aside>
        <div className="reference-content relative min-w-0 flex-1 overflow-hidden md:mr-5 md:mt-2 md:rounded-t-[20px]">
          {bannerVisible && <div className="escrow-banner relative flex min-h-16 items-center gap-3 px-5 py-3 text-center"><ShieldCheck className="h-6 w-6 shrink-0 text-primary" /><p className="mx-auto max-w-xl text-sm sm:text-base">Add an extra layer of protection for your transactions with our Middle Man service. <Link to="/escrow" className="text-primary underline">[Explore Escrow]</Link></p><Button variant="ghost" size="icon" aria-label="Dismiss escrow banner" onClick={() => setBannerVisible(false)} className="h-6 w-6 shrink-0"><X /></Button></div>}
          <div className="flex items-center gap-1 border-b border-border px-3 py-3 md:hidden"><Button variant="ghost" size="icon" aria-label="Open navigation" onClick={() => setMenuOpen(true)} className="h-9 w-9 shrink-0"><Menu /></Button><Link to="/" className="text-lg font-bold">dealer<span className="text-primary">2470</span></Link></div>
          {children}
        </div>
      </div>
    </div>
  );
}