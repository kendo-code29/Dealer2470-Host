export type Role = "buyer" | "seller" | "escrow";
export type Tier = 1 | 2 | 3;

export const naira = (n: number) => "₦" + n.toLocaleString("en-NG");

export const categories: { name: string; tier: Tier; note: string }[] = [
  { name: "Fashion", tier: 1, note: "Phone verified" },
  { name: "Home & Living", tier: 1, note: "Phone verified" },
  { name: "Services", tier: 1, note: "Phone verified" },
  { name: "Phones & Gadgets", tier: 2, note: "ID + IMEI check" },
  { name: "Electronics", tier: 2, note: "ID verified" },
  { name: "Vehicles", tier: 3, note: "ID, papers & inspection" },
  { name: "Real Estate", tier: 3, note: "ID, title docs & agent" },
];

export type Listing = { id: string; title: string; category: string; price: number; seller: string; city: string; tags: string[]; stock: number };

export const listings: Listing[] = [
  { id: "l1", title: "iPhone 15 Pro 256GB", category: "Phones & Gadgets", price: 1450000, seller: "TechHub Ikeja", city: "Lagos", tags: ["apple", "phone"], stock: 4 },
  { id: "l2", title: "Samsung 55\" QLED TV", category: "Electronics", price: 620000, seller: "Volt Store", city: "Abuja", tags: ["tv", "samsung"], stock: 7 },
  { id: "l3", title: "Toyota Camry 2018", category: "Vehicles", price: 14500000, seller: "AutoLink NG", city: "Lagos", tags: ["car", "toyota"], stock: 1 },
  { id: "l4", title: "Ankara Two-Piece Set", category: "Fashion", price: 28000, seller: "Ada Couture", city: "Enugu", tags: ["ankara", "women"], stock: 22 },
  { id: "l5", title: "3-Bed Flat, Lekki Ph.1", category: "Real Estate", price: 95000000, seller: "Prime Homes", city: "Lagos", tags: ["apartment"], stock: 1 },
  { id: "l6", title: "MacBook Air M3", category: "Electronics", price: 1650000, seller: "TechHub Ikeja", city: "Lagos", tags: ["apple", "laptop"], stock: 3 },
  { id: "l7", title: "Home Deep Cleaning", category: "Services", price: 45000, seller: "SparkleCrew", city: "Port Harcourt", tags: ["cleaning"], stock: 99 },
  { id: "l8", title: "Velvet 3-Seater Sofa", category: "Home & Living", price: 380000, seller: "Nest Interiors", city: "Ibadan", tags: ["sofa", "furniture"], stock: 5 },
  { id: "l9", title: "AirPods Pro 2", category: "Phones & Gadgets", price: 310000, seller: "Volt Store", city: "Abuja", tags: ["apple", "audio"], stock: 12 },
  { id: "l10", title: "Lexus RX 350 2016", category: "Vehicles", price: 22000000, seller: "AutoLink NG", city: "Abuja", tags: ["car", "lexus"], stock: 1 },
];

export const tierOf = (cat: string): Tier => categories.find((c) => c.name === cat)?.tier ?? 1;

export type DealStage = "Funded" | "Shipped" | "Verifying" | "Released" | "Disputed";
export const deals = [
  { id: "ESC-1042", item: "iPhone 15 Pro 256GB", buyer: "Tunde A.", seller: "TechHub Ikeja", amount: 1450000, stage: "Verifying" as DealStage },
  { id: "ESC-1041", item: "Toyota Camry 2018", buyer: "Chioma O.", seller: "AutoLink NG", amount: 14500000, stage: "Funded" as DealStage },
  { id: "ESC-1039", item: "Velvet 3-Seater Sofa", buyer: "Musa B.", seller: "Nest Interiors", amount: 380000, stage: "Disputed" as DealStage },
  { id: "ESC-1036", item: "Ankara Two-Piece Set", buyer: "Tunde A.", seller: "Ada Couture", amount: 28000, stage: "Shipped" as DealStage },
  { id: "ESC-1030", item: "AirPods Pro 2", buyer: "Grace E.", seller: "Volt Store", amount: 310000, stage: "Released" as DealStage },
];

/** Rank listings by overlap with recent activity tags/categories (Window Shop). */
export function recommend(activity: string[], all: Listing[] = listings): Listing[] {
  const score = (l: Listing) => activity.reduce((s, a) => s + (l.tags.includes(a) ? 2 : 0) + (l.category === a ? 1 : 0), 0);
  return [...all].sort((a, b) => score(b) - score(a));
}
