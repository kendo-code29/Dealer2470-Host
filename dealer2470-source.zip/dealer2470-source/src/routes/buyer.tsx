import { createFileRoute } from "@tanstack/react-router";
import { EscrowBadge, Panel, Row, Shell, Stat } from "@/components/Shell";
import { deals, listings, naira } from "@/lib/demo";

export const Route = createFileRoute("/buyer")({
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { title: "Buyer Portal — Dealer247" },
      { name: "description", content: "Track orders, shipments and your wishlist on Dealer247." },
      { property: "og:title", content: "Buyer Portal — Dealer247" },
      { property: "og:description", content: "Your orders and shipments in one place." },
    ],
  }),
  component: Buyer,
});

function Buyer() {
  const mine = deals.filter((d) => d.buyer === "Tunde A.");
  return (
    <Shell title="Buyer Portal">
      <div className="mb-6 grid gap-4 sm:grid-cols-3">
        <Stat label="ACTIVE ORDERS" value={String(mine.length)} />
        <Stat label="IN ESCROW" value={naira(mine.reduce((s, d) => s + d.amount, 0))} />
        <Stat label="WISHLIST" value="3" />
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <Panel title="Active orders">
          {mine.map((d) => <Row key={d.id}><span>{d.item}<br /><span className="font-mono text-xs text-muted-foreground">{d.id}</span></span><span className="text-right"><span className="font-mono text-gold">{naira(d.amount)}</span><br /><span className="text-xs">{d.stage}</span></span></Row>)}
          <div className="mt-3"><EscrowBadge small /></div>
        </Panel>
        <Panel title="Tracked shipments">
          <Row><span>Ankara Two-Piece Set</span><span className="text-xs text-accent">Enugu → Lagos · ETA 2 days</span></Row>
          <Row><span>iPhone 15 Pro</span><span className="text-xs text-accent">Delivered · awaiting your check</span></Row>
        </Panel>
        <Panel title="Saved wishlist">
          {listings.slice(5, 8).map((l) => <Row key={l.id}><span>{l.title}</span><span className="font-mono">{naira(l.price)}</span></Row>)}
        </Panel>
        <Panel title="Quick-purchase history">
          {deals.filter((d) => d.stage === "Released").map((d) => <Row key={d.id}><span>{d.item}</span><button className="rounded bg-secondary px-3 py-1 text-xs">Buy again</button></Row>)}
        </Panel>
      </div>
    </Shell>
  );
}
