import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { ShieldCheck } from "lucide-react";
import { EscrowBadge, Panel, Shell, TierBadge } from "@/components/Shell";
import { categories, listings, naira, tierOf } from "@/lib/demo";

export const Route = createFileRoute("/deals")({
  validateSearch: (s: Record<string, unknown>): { item?: string | undefined } => ({ item: typeof s["item"] === "string" ? s["item"] : undefined }),
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { title: "Deals & Offers — Dealer247" },
      { name: "description", content: "Make offers, chat with sellers and open escrow-protected transactions." },
      { property: "og:title", content: "Deals & Offers — Dealer247" },
      { property: "og:description", content: "Offers become secure chats and escrow requests." },
    ],
  }),
  component: Deals,
});

function Deals() {
  const { item } = Route.useSearch();
  const l = listings.find((x) => x.id === item) ?? listings[0]!;
  const tier = tierOf(l.category);
  const [offer, setOffer] = useState(Math.round(l.price * 0.95));
  const [msgs, setMsgs] = useState<{ me: boolean; t: string }[]>([]);
  const [text, setText] = useState("");
  const [verified, setVerified] = useState(false);
  const [opened, setOpened] = useState(false);

  const send = () => {
    setMsgs((m) => [...m, { me: true, t: `Offer: ${naira(offer)}` }, { me: false, t: `${l.seller}: Thanks! I can accept ${naira(Math.round((offer + l.price) / 2))}.` }]);
  };

  return (
    <Shell title="Deal room">
      <div className="grid gap-4 lg:grid-cols-3">
        <Panel title="Item">
          <div className="space-y-2">
            <div className="flex items-center gap-2"><h3 className="font-display text-lg font-semibold leading-snug">{l.title}</h3><TierBadge tier={tier} /></div>
            <div className="font-mono text-2xl text-gold">{naira(l.price)}</div>
            <div className="text-xs text-muted-foreground">{l.seller} · {l.city}</div>
            <EscrowBadge small />
            <p className="pt-2 text-xs text-muted-foreground">Required: {categories.find((c) => c.name === l.category)?.note}</p>
          </div>
        </Panel>
        <div className="lg:col-span-2">
          <Panel title="Secure channel">
            <div className="mb-3 h-56 space-y-2 overflow-y-auto rounded bg-background p-3">
              {msgs.length === 0 && <p className="text-sm text-muted-foreground">Send an offer to open a private chat with the seller.</p>}
              {msgs.map((m, i) => <p key={i} className={`max-w-[80%] rounded-lg px-3 py-2 text-sm ${m.me ? "ml-auto bg-primary text-primary-foreground" : "bg-secondary"}`}>{m.t}</p>)}
            </div>
            <div className="flex flex-wrap gap-2">
              <input type="number" value={offer} onChange={(e) => setOffer(+e.target.value)} className="w-40 rounded-md border border-input bg-background px-3 py-2 font-mono text-sm" />
              <button onClick={send} className="rounded-md bg-secondary px-4 py-2 text-sm">Send offer</button>
              <input value={text} onChange={(e) => setText(e.target.value)} placeholder="Message" className="min-w-0 flex-1 rounded-md border border-input bg-background px-3 py-2 text-sm" />
              <button onClick={() => { if (text) { setMsgs((m) => [...m, { me: true, t: text }]); setText(""); } }} className="rounded-md bg-secondary px-4 py-2 text-sm">Send</button>
            </div>
            {msgs.length > 0 && (
              <div className="mt-4 rounded-lg border border-accent/40 bg-accent/5 p-4">
                {opened ? (
                  <p className="flex items-center gap-2 text-sm text-accent"><ShieldCheck className="h-4 w-4" /> Escrow request sent. A Middle Man will hold your {naira(offer)} until you confirm delivery.</p>
                ) : (
                  <div className="space-y-3">
                    <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={verified} onChange={(e) => setVerified(e.target.checked)} /> I confirm my identity (level {tier} check) and agree funds are held in escrow.</label>
                    <button disabled={!verified} onClick={() => setOpened(true)} className="rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-colors hover:bg-gold disabled:opacity-40">Open escrow transaction</button>
                  </div>
                )}
              </div>
            )}
          </Panel>
        </div>
      </div>
    </Shell>
  );
}
