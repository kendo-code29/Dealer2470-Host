import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Search, Plus, Compass, ArrowRightLeft, ChevronDown, Sparkles, ArrowUpRight, ShieldCheck } from "lucide-react";
import { DashboardFrame } from "@/components/DashboardFrame";
import { Button } from "@/components/ui/button";
import laptop from "@/assets/laptop.asset.json";
import produce from "@/assets/produce.asset.json";
import watch from "@/assets/watch.asset.json";
import smartwatch from "@/assets/smartwatch.asset.json";
import headphones from "@/assets/headphones.asset.json";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "Home — dealer2470 Marketplace" },
    { name: "description", content: "Discover products, manage your listings and explore escrow-protected trading on dealer2470." },
    { property: "og:title", content: "Home — dealer2470 Marketplace" },
    { property: "og:description", content: "Your marketplace for discovering products and connecting with buyers, sellers and Middle Man agents." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: Index,
});

const suggestions = [
  { title: "Trending Laptops", price: "$720", image: laptop.url, query: "MacBook" },
  { title: "Local Produce", price: "$10.00", image: produce.url, query: "produce" },
  { title: "Vintage Watches", price: "$5.50", image: watch.url, query: "watch" },
  { title: "Brain Watcher", price: "$8.90", image: smartwatch.url, query: "smart watch" },
  { title: "Dishangoth", price: "$3.90", image: headphones.url, query: "controller" },
];

function Index() {
  const [query, setQuery] = useState("");
  const [mode, setMode] = useState("find");
  const navigate = useNavigate();
  return <DashboardFrame>
    <main className="reference-home mx-auto max-w-[1200px] px-5 pb-10 pt-9 md:px-14">
      <header className="mb-10 flex flex-col items-center text-center">
        <Link to="/escrow" className="reference-escrow inline-flex w-fit items-center gap-3 rounded-full border border-border px-4 py-2 text-base font-semibold"><ShieldCheck className="h-6 w-6 text-primary" />Escrow Protection</Link>
        <h1 className="mt-16 text-3xl font-bold leading-tight">Got an idea, Dealer?</h1>
      </header>
      <section className="mb-6">
        <form onSubmit={e => { e.preventDefault(); if (mode === "find") navigate({ to: "/shop", search: { q: query } }); else navigate({ to: mode === "list" ? "/seller" : "/deals" }); }} className="command-box rounded-[32px] border-2 border-primary bg-command px-6 py-5">
          <input aria-label="Find products or manage listings" value={query} onChange={e => setQuery(e.target.value)} placeholder="Ask Dealer247 to find... or list... or manage..." className="w-full min-w-0 bg-transparent py-2 text-base outline-none" />
          <div className="mt-2 flex items-center justify-between gap-2">
            <Button type="submit" size="icon" variant="ghost" aria-label="Go" title="Go" className="h-7 w-7"><Plus /></Button>
            <div className="relative"><select aria-label="Find or list mode" value={mode} onChange={e => setMode(e.target.value)} className="h-8 appearance-none rounded-lg border border-border bg-secondary pl-3 pr-8 text-sm font-semibold"><option value="find">Find / List</option><option value="list">Create Listing</option><option value="manage">Transactions</option></select><ChevronDown className="pointer-events-none absolute right-2 top-2.5 h-3.5 w-3.5" /></div>
          </div>
        </form>
        <div className="reference-actions mt-4 flex flex-wrap gap-2">
          <Button asChild variant="outline" size="sm" className="bg-card text-foreground"><Link to="/shop" search={{ q: query }}><Search className="text-primary" />Find Products</Link></Button>
          <Button asChild variant="outline" size="sm" className="bg-card text-foreground"><Link to="/seller"><Plus className="text-primary" />Create Listing</Link></Button>
          <Button asChild variant="outline" size="sm" className="bg-card text-foreground"><Link to="/shop"><Compass className="text-primary" />Browse Window Shop</Link></Button>
          <Button asChild variant="outline" size="sm" className="bg-card text-foreground"><Link to="/buyer"><ArrowRightLeft className="text-primary" />My Transactions</Link></Button>
        </div>
      </section>
      <section>
        <div className="mb-3"><h2 className="text-base font-semibold">Suggested Items <span className="text-sm font-normal text-muted-foreground">(Based on your activity)</span></h2></div>
        <div className="reference-feed flex gap-3 overflow-x-auto pb-3">
          {suggestions.map(item => <article key={item.title} className="group w-32 shrink-0 overflow-hidden rounded-2xl border border-border bg-card p-1.5 transition-colors hover:border-primary/60"><Link to="/shop" search={{ q: item.query }} aria-label={`Browse ${item.title}`}><img src={item.image} alt={item.title} className="aspect-[4/3] w-full rounded-lg object-cover" /></Link><div className="px-0.5 pt-2"><h3 className="truncate text-xs font-medium leading-4">{item.title}</h3><div className="mt-2 flex items-center justify-between gap-2"><span className="text-xs font-medium">{item.price}</span><Button asChild size="sm" variant="secondary" className="h-6 rounded-md px-2.5 text-xs"><Link to="/shop" search={{ q: item.query }}>View</Link></Button></div></div></article>)}
        </div>
      </section>
    </main>
  </DashboardFrame>;
}