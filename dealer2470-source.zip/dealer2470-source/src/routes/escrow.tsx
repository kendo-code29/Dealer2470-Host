import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Panel, Row, Shell, Stat } from "@/components/Shell";
import { deals as seed, naira, type DealStage } from "@/lib/demo";

export const Route = createFileRoute("/escrow")({
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { title: "Middle Man Portal — Dealer247" },
      { name: "description", content: "Escrow queue, trade verification, disputes and fund release on Dealer247." },
      { property: "og:title", content: "Middle Man Portal — Dealer247" },
      { property: "og:description", content: "Hold, verify and release escrow funds." },
    ],
  }),
  component: Escrow,
});

function Escrow() {
  const [deals, setDeals] = useState(seed);
  const [log, setLog] = useState<string[]>(["ESC-1039 · Buyer reports torn fabric · photos attached"]);
  const set = (id: string, stage: DealStage, note: string) => {
    setDeals((d) => d.map((x) => (x.id === id ? { ...x, stage } : x)));
    setLog((l) => [`${id} · ${note}`, ...l]);
  };
  const held = deals.filter((d) => d.stage !== "Released").reduce((s, d) => s + d.amount, 0);
  return (
    <Shell title="Middle Man Portal">
      <div className="mb-6 grid gap-4 sm:grid-cols-3">
        <Stat label="FUNDS HELD" value={naira(held)} />
        <Stat label="AWAITING VERIFY" value={String(deals.filter((d) => d.stage === "Verifying").length)} />
        <Stat label="OPEN DISPUTES" value={String(deals.filter((d) => d.stage === "Disputed").length)} />
      </div>
      <div className="grid gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <Panel title="Escrow queue">
            {deals.map((d) => (
              <Row key={d.id}>
                <span>
                  <span className="font-mono text-xs text-muted-foreground">{d.id}</span> {d.item}
                  <br /><span className="text-xs text-muted-foreground">{d.buyer} → {d.seller} · {naira(d.amount)}</span>
                </span>
                <span className="flex flex-wrap justify-end gap-1.5">
                  <span className="font-mono text-xs">{d.stage}</span>
                  {d.stage !== "Released" && (
                    <>
                      <button onClick={() => set(d.id, "Released", "Funds released to seller")} className="rounded bg-accent px-2 py-1 text-xs font-semibold text-accent-foreground">Release</button>
                      {d.stage !== "Disputed" && <button onClick={() => set(d.id, "Disputed", "Dispute opened")} className="rounded border border-destructive/50 bg-destructive/15 px-2 py-1 text-xs text-destructive">Dispute</button>}
                    </>
                  )}
                </span>
              </Row>
            ))}
          </Panel>
        </div>
        <Panel title="Dispute & action log">
          {log.map((l, i) => <p key={i} className="border-b border-border py-2 font-mono text-xs last:border-0">{l}</p>)}
        </Panel>
      </div>
    </Shell>
  );
}
