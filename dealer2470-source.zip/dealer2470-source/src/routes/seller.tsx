import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Panel, Row, Shell, Stat, TierBadge } from "@/components/Shell";
import { deals, listings, naira, tierOf } from "@/lib/demo";

export const Route = createFileRoute("/seller")({
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { title: "Seller Dashboard — Dealer247" },
      { name: "description", content: "Manage inventory, listings, fulfilment and payouts on Dealer247." },
      { property: "og:title", content: "Seller Dashboard — Dealer247" },
      { property: "og:description", content: "Inventory, orders and payouts for sellers." },
    ],
  }),
  component: Seller,
});

function Seller() {
  const [stock, setStock] = useState(() => Object.fromEntries(listings.slice(0, 6).map((l) => [l.id, l.stock])));
  const paid = deals.filter((d) => d.stage === "Released").reduce((s, d) => s + d.amount, 0);
  const pending = deals.filter((d) => d.stage !== "Released").reduce((s, d) => s + d.amount, 0);
  return (
    <Shell title="Seller Dashboard">
      <div className="mb-6 grid gap-4 sm:grid-cols-3">
        <Stat label="PAID OUT" value={naira(paid)} />
        <Stat label="HELD IN ESCROW" value={naira(pending)} />
        <Stat label="ACTIVE LISTINGS" value={String(Object.keys(stock).length)} />
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <Panel title="Inventory">
          {listings.slice(0, 6).map((l) => (
            <Row key={l.id}>
              <span className="flex min-w-0 items-center gap-2"><span className="truncate">{l.title}</span> <TierBadge tier={tierOf(l.category)} /></span>
              <span className="flex shrink-0 items-center gap-2 font-mono">
                <button onClick={() => setStock((s) => ({ ...s, [l.id]: Math.max(0, (s[l.id] ?? 0) - 1) }))} className="rounded bg-secondary px-2">−</button>
                <span className="w-7 text-center tabular-nums">{stock[l.id]}</span>
                <button onClick={() => setStock((s) => ({ ...s, [l.id]: (s[l.id] ?? 0) + 1 }))} className="rounded bg-secondary px-2">+</button>
              </span>
            </Row>
          ))}
        </Panel>
        <Panel title="Order fulfilment">
          {deals.map((d) => <Row key={d.id}><span>{d.item}<br /><span className="text-xs text-muted-foreground">to {d.buyer}</span></span><span className={`font-mono text-xs ${d.stage === "Disputed" ? "text-destructive" : d.stage === "Released" ? "text-accent" : "text-primary"}`}>{d.stage.toUpperCase()}</span></Row>)}
        </Panel>
      </div>
    </Shell>
  );
}
