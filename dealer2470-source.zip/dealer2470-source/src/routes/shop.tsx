import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Heart, Search } from "lucide-react";
import { EscrowBadge, Shell, TierBadge } from "@/components/Shell";
import { categories, listings, naira, recommend, tierOf } from "@/lib/demo";

export const Route = createFileRoute("/shop")({
  validateSearch: (s: Record<string, unknown>): { q?: string | undefined } => ({ q: typeof s["q"] === "string" ? s["q"] : undefined }),
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { title: "Window Shop — Dealer247" },
      { name: "description", content: "A discovery feed that adapts to what you like, view and search on Dealer247." },
      { property: "og:title", content: "Window Shop — Dealer247" },
      { property: "og:description", content: "Personalised picks, all escrow protected." },
    ],
  }),
  component: Shop,
});

function Shop() {
  const { q: searchQuery } = Route.useSearch();
  const [activity, setActivity] = useState<string[]>(["apple"]);
  const [localQuery, setLocalQuery] = useState<string | null>(null);
  const q = localQuery ?? searchQuery ?? "";
  const setQ = setLocalQuery;
  const [cat, setCat] = useState<string | null>(null);
  const track = (...a: string[]) => setActivity((p) => [...a, ...p].slice(0, 8));
  const feed = useMemo(() => {
    const base = recommend(activity).filter((l) => !cat || l.category === cat);
    return q ? base.filter((l) => [l.title, l.category, ...l.tags].join(" ").toLowerCase().includes(q.toLowerCase())) : base;
  }, [activity, q, cat]);

  return (
    <Shell title="Window Shop">
      <div className="mb-4 flex items-center gap-2 rounded-md border border-input bg-card px-3">
        <Search className="h-4 w-4 text-muted-foreground" />
        <input value={q} onChange={(e) => setQ(e.target.value)} onBlur={() => q && track(q.toLowerCase())} placeholder="Search goods & services" className="w-full bg-transparent py-2 text-sm outline-none" />
      </div>
      <div className="mb-4 flex flex-wrap gap-2">
        <button onClick={() => setCat(null)} className={`rounded-full px-3 py-1 text-xs ${!cat ? "bg-accent text-accent-foreground" : "bg-secondary"}`}>All</button>
        {categories.map((c) => (
          <button key={c.name} onClick={() => { setCat(c.name); track(c.name); }} className={`flex items-center gap-1.5 rounded-full px-3 py-1 text-xs ${cat === c.name ? "bg-accent text-accent-foreground" : "bg-secondary"}`}>
            {c.name} <span className="opacity-60">L{c.tier}</span>
          </button>
        ))}
      </div>
      <p className="mb-6 font-mono text-xs text-muted-foreground">TUNED TO: {activity.slice(0, 5).join(" · ")}</p>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {feed.length === 0 && <div className="col-span-full py-10 text-center"><h2 className="font-semibold">No matching products</h2><p className="mt-2 text-sm text-muted-foreground">No current listings match “{q}”.</p><Link to="/shop" search={{ q: undefined }} onClick={() => { setLocalQuery(null); setCat(null); }} className="mt-4 inline-block text-sm text-primary">Browse all products</Link></div>}
        {feed.map((l) => (
          <article key={l.id} onMouseEnter={() => track(l.category)} className="flex flex-col gap-3 rounded-lg border border-border bg-card p-4 hover:border-accent/60">
            <div className="flex items-center justify-between"><span className="text-xs text-muted-foreground">{l.category}</span><TierBadge tier={tierOf(l.category)} /></div>
            <h3 className="font-display text-lg font-semibold leading-snug">{l.title}</h3>
            <div className="font-mono text-xl text-gold">{naira(l.price)}</div>
            <div className="text-xs text-muted-foreground">{l.seller} · {l.city}</div>
            <div className="mt-auto flex items-center justify-between">
              <EscrowBadge small />
              <div className="flex gap-2">
                <button aria-label="Like" onClick={() => track(...l.tags)} className="rounded p-1.5 hover:bg-secondary"><Heart className="h-4 w-4" /></button>
                <Link to="/deals" search={{ item: l.id }} className="rounded bg-primary px-3 py-1 text-xs font-semibold text-primary-foreground transition-colors hover:bg-gold">Make offer</Link>
              </div>
            </div>
          </article>
        ))}
      </div>
      <p className="mt-6 text-xs text-muted-foreground">{listings.length} live listings. Higher-value categories need more verification (L1–L3).</p>
    </Shell>
  );
}
